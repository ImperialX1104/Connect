<?php
include('connection.inc.php');
// Retrieve the image URL from the request parameters
$_POST = json_decode(file_get_contents('php://input'), true);
$image_url=($_POST['src']);
$img = explode('/',$image_url);
// Delete the corresponding file from your server
if (unlink(BLOG_IMAGE_SERVER_PATH.end($img))) {
  // Return a success response
  echo json_encode(['status' => 'success']);
} else {
  // Return an error response
  echo json_encode(['status' => 'error']);
}
?>