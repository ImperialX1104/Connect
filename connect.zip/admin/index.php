<?php
include('connection.inc.php');

// Check if the user is already logged in, redirect to the home page if true
if (isset($_SESSION['user_id'])) {
    header('Location: /admin/dashboard');
    exit;
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the login form is submitted
    if (isset($_POST['login'])) {
        // Perform login validation
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Query to check if the provided username or email and password are valid
        $query = "SELECT * FROM admins WHERE (username=? OR email=?)";

        // Replace 'your_table_name' with the actual name of your user table
        $stmt = mysqli_prepare($con, $query);

        // Bind parameters correctly
        mysqli_stmt_bind_param($stmt, 'ss', $username, $username);

        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        mysqli_stmt_close($stmt);

        // If a matching user is found, verify the password and log them in, then redirect to the home page
        if (mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['adminName'] = $user['fullname'];
                header('Location: /admin/dashboard');
                exit;
            } else {
                $message = '<div class="alert alert-danger" role="alert">Invalid password.</div>';
            }
        } else {
            $message = '<div class="alert alert-danger" role="alert">Invalid username or email.</div>';
        }

        mysqli_close($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect-Admin Panel - Login</title>
    <!-- Add Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <!-- Header -->
    <header class="bg-dark text-light py-4">
        <div class="container text-center">
            <img src="/assets/img/logo.png" width="180px" height="150px" class="img-fluid">
            <h1 class="m-0">Connect-Admin Panel</h1>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center mb-4">Login Admin</h2>
                <?php echo $message; ?>
                <!-- Login Form -->
                <form id="loginForm" method="post" action="">
                    <div class="form-group">
                        <label for="username">Username or Email:</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary btn-block">Login</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and custom script -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
    <!-- Footer -->
    <footer class="bg-light text-center py-3 mt-5">
        <p class="m-0">&copy; 2023 Connect. All Rights Reserved</p>
        <p class="m-0">Designed by Offensive Technology</p>
    </footer>
</body>

</html>
