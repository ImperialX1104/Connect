<?php
// Start the session
session_start();

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the login page (assuming the login page is named login.php)
header("Location: /admin");
exit;
?>
