 <!-- ======= CTA Section ======= -->
 <section class="section cta-section">
     <div class="container">
         <div class="row align-items-center">
             <div class="col-md-6 me-auto text-center text-md-start mb-5 mb-md-0">
                 <h2>Download Now !</h2>
             </div>
             <div class="col-md-5 text-center text-md-end">
                 <p><a href="#" class="btn d-inline-flex align-items-center"><i class="bx bxl-play-store"></i><span>Google
                             play</span></a></p>
             </div>
         </div>
     </div>
 </section><!-- End CTA Section -->