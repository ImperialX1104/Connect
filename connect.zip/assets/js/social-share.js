// Get the URL of the current page
var currentUrl = window.location.href;
var pageTitle = document.title;
// Get the text to share
var textToShare = "Hey, have a look on this \n*" + pageTitle +"*\n"+currentUrl;
// Encode the text for use in a URL
var encodedText = encodeURIComponent(textToShare);
// Generate the WhatsApp share link
var whatsappLink = "https://api.whatsapp.com/send?text=" + encodedText;
// Update the href values of the share buttons
document.getElementById("whatsapp-social-button").href = "https://api.whatsapp.com/send?text=" + encodedText;
document.getElementById("facebook-social-button").href = "https://www.facebook.com/sharer/sharer.php?u=" + currentUrl;
document.getElementById("twitter-social-button").href = "https://twitter.com/intent/tweet?url=" + currentUrl;
document.getElementById("linkedin-social-button").href = "https://www.linkedin.com/shareArticle?mini=true&url=" + currentUrl;
document.getElementById("reddit-social-button").href = "https://www.reddit.com/submit?url=" + currentUrl;

