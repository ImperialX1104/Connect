document.getElementById("form").addEventListener("submit", function(event) {
  event.preventDefault();

  var form = event.target;
  var formData = new FormData(form);
 // Show loading indicator
  document.querySelector('.loading').style.display = 'block';
  fetch("mail", {
    method: "POST",
    body: formData
  })
  .then(function(response) {
    // Check if the response is a JSON
    if (response.ok && response.headers.get("Content-Type").includes("application/json")) {
        return response.json(); // Parse the JSON data
    } else {
      throw new Error("Invalid response from the server.");
    }
  })
  .then(function(data) {
    // Handle the data received from the server
    // Hide loading indicator
    document.querySelector('.loading').style.display = 'none';
    if (data.status === "success") {
      document.querySelector('.sent-message').style.display = 'block';
      document.querySelector('.error-message').style.display = 'none';
    } else {
      document.querySelector('.error-message').style.display = 'block';
      document.querySelector('.sent-message').style.display = 'none';
      document.querySelector('.error-message').innerHTML = "Error: " + data.message;
    }
  })
  .catch(function(error) {
    // Handle errors
     // Hide loading indicator
    document.querySelector('.loading').style.display = 'none';
    document.querySelector('.error-message').style.display = 'block';
    document.querySelector('.sent-message').style.display = 'none';
    document.querySelector('.error-message').innerHTML = "Error: Failed to communicate with the server.";
  });
});
