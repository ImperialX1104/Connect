<?php 
ob_start();
include('header.php'); 

$message="";
if(isset($_GET['id'])){
  $id=secure_value($con,$_GET['id']);
 
      if(isset($_GET['del'])){
          if(mysqli_query($con,"DELETE FROM blogpost WHERE id=$id")){
              $message='<div class="alert alert-dark" role="alert">
                         Blog Deleted Successfully!
                        </div>';

          }else{
              $message='<div class="alert alert-danger" role="alert">
                        Unkown error occurred.
                        </div>';

          }
      }
      if(isset($_GET['status'])){
          $status=secure_value($con,$_GET['status']);
          if($status==0){
              if(mysqli_query($con,"UPDATE blogpost SET status=0 WHERE id=$id")){
                
                 $message='<div class="alert alert-warning" role="alert">
                         Blog Deactivated Successfully!
                        </div>';

                  
                }else{
                    $message='<div class="alert alert-danger" role="alert">
                        Unkown error occurred.
                        </div>';

                  
                }
          }
          if($status==1){
              if(mysqli_query($con,"UPDATE blogpost SET status=1 WHERE id=$id")){
                 $message='<div class="alert alert-success" role="alert">
                         Blog Activated Successfully!
                        </div>';

                }else{
                    $message='<div class="alert alert-danger" role="alert">
                        Unkown error occurred.
                        </div>';
                }
          }
      }
    }


?>

  <main id="main">

    <section class="hero-section inner-page">
      <div class="wave">

        <svg width="1920px" height="265px" viewBox="0 0 1920 265" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="Apple-TV" transform="translate(0.000000, -402.000000)" fill="#FFFFFF">
              <path d="M0,439.134243 C175.04074,464.89273 327.944386,477.771974 458.710937,477.771974 C654.860765,477.771974 870.645295,442.632362 1205.9828,410.192501 C1429.54114,388.565926 1667.54687,411.092417 1920,477.771974 L1920,667 L1017.15166,667 L0,667 L0,439.134243 Z" id="Path"></path>
            </g>
          </g>
        </svg>

      </div>

      <div class="container">
        <div class="row align-items-center">
          <div class="col-12">
            <div class="row justify-content-center">
              <div class="col-md-7 text-center hero-text">
                <h1 data-aos="fade-up" data-aos-delay="">Admin Panel</h1>
                <p class="mb-5" data-aos="fade-up" data-aos-delay="100">Simplify control, manage with ease, conquer your tasks.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>

    <section class="section">
      <div class="container">
        <div class="row mb-5 align-items-end">
          <div class="col-md-6">

            <h2>Blog Master</h2>
       <?php
        if (!empty($message)) {
          echo $message;
          // Clear the message after printing it
          $message = "";
        }
        ?>
          </div>

        </div>

        <div class="row">
          <div class="col-md-12 mb-5 mb-md-0">
            <!-- Blogs Manager frame -->
                    <div class="art-a art-card">

                      <!-- Blogs Table -->
                      <table class="table text-white">
                        <thead class="text-warning">
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Title</th>
                            <th scope="col">Action</th>
                            </tr>
                        </thead>
                       <tbody>
                            <?php 
                            $res=mysqli_query($con,"SELECT * FROM blogpost ORDER BY id DESC");
                                if(mysqli_num_rows($res)>0)
                                     while($blogPost=mysqli_fetch_assoc($res)){
                            ?>
                            <tr>
                            <th scope="row"><?php echo $blogPost['id'] ?></th>
                            <td><a href="/blog/<?php echo $blogPost['slug'] ?>"><?php echo $blogPost['title'] ?></a></td>
                            <?php 
                                 if ($blogPost['status'] == 1) {
                                    echo "<td>
                                              <span class='badge bg-success'>
                                                <a class='link-dark text-white' href='?id=" . $blogPost['id'] . "&status=0'>Active</a>
                                              </span>&nbsp;
                                              <span class='badge bg-info'>
                                                <a class='link-dark text-white' href='blog-master.php/?id=" . $blogPost['id'] . "'>Edit</a>
                                              </span>&nbsp;
                                              <span class='badge bg-danger'>
                                                <a class='link-dark text-white' href='javascript:void(0);' onclick='confirmDelete(" . $blogPost['id'] . ")'>Delete</a>
                                              </span>&nbsp;
                                            </td>";
                                  } else {
                                    echo "<td>
                                              <span class='badge bg-warning'>
                                                <a class='link-dark text-dark' href='?id=" . $blogPost['id'] . "&status=1'>Deactivate</a>
                                              </span>&nbsp;
                                              <span class='badge bg-info'>
                                                <a class='link-dark text-white' href='blog-master.php/?id=" . $blogPost['id'] . "'>Edit</a>
                                              </span>&nbsp;
                                              <span class='badge bg-danger'>
                                                <a class='link-dark text-white' href='javascript:void(0);' onclick='confirmDelete(" . $blogPost['id'] . ")'>Delete</a>
                                              </span>&nbsp;
                                            </td>";
                                  }
                            ?>
                            
                            </tr>
                            <?php } ?>
                        </tbody>
                        </table>
                      <!-- blogs table end -->

                    </div>
                    <!-- Blogs Manager frame end -->
          </div>

        </div>
      </div>
    </section>

   
  </main><!-- End #main -->
  <script>
   function confirmDelete(id) {
    if (confirm("Are you sure you want to delete this blog post?")) {
      window.location.href = "?id=" + id + "&del=true";
    }
  }
  // JavaScript to remove parameters from the URL after printing the message
  if (typeof window.history.replaceState === 'function') {
    window.history.replaceState({}, document.title, window.location.pathname);
  }
</script>
<?php include('footer.php'); ?>