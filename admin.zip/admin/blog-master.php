<?php include('header.php'); 
$error="";
$title="";
$description="";
$banner="";
$content="";
$author="";
$publishedOn="";
$category="";
$keywords="";
$required="required";

#update previous blog with ID
if(isset($_POST['submit']) && isset($_GET['id'])){

  $id=secure_value($con,$_GET['id']);
  $title=secure_value($con,$_POST['title']);
  $description=secure_value($con,$_POST['short_desc']);
  if(isset($_POST['image'])){
  $banner=secure_value($con,$_POST['image']);
    if(isset($_FILES['image'])){
    $image=rand(1111111,9999999).'_'.$_FILES['image']['name'];;
    move_uploaded_file($_FILES['image']['tmp_name'],BLOG_IMAGE_SERVER_PATH.$image);
    $banner=$image;
  
   }
  }
  $content=secure_value($con,$_POST['content']);
 $content=substr($content,0,  strlen($content)-237);
  $author=secure_value($con,$_POST['author']);
  $publishedOn=secure_value($con,$_POST['publishedOn']);
  $category=secure_value($con,$_POST['category']);
  $keywords=secure_value($con,$_POST['tags']);
  $slug=$title;
  $slug=slugify($slug);
    
  $prev_slug=mysqli_fetch_assoc(mysqli_query($con,"SELECT slug FROM blogpost WHERE id=$id")); 
  if($prev_slug['slug']!=$slug){
  $slug_check=mysqli_num_rows(mysqli_query($con,"SELECT id FROM blogpost WHERE slug='$slug'"));
  if($slug_check>0){
    $row=mysqli_fetch_assoc(mysqli_query($con,"SELECT MAX(id) as id FROM blogpost"));
    $latestid=$row['id']+=1;
    $slug.=$latestid;
  }
 }
  $update_query="UPDATE `blogpost` SET `title` = '$title',`description`='$description',`content`='$content',`author`='$author',`date`='$publishedOn',`category`='$category',`keywords`='$keywords',`slug`='$slug' ";

  if ($banner!= ""){
    $update_query.=",`banner`,='$banner'";
  }
  $update_query.=" WHERE `id` = $id;";

  if(mysqli_query($con,$update_query)){
    $error='<div class="alert alert-info" role="alert">
    <strong>Blog updated successfully.</strong>
  </div>';
  }else{
    $error='<div class="alert alert-danger" role="alert">
    <strong>Some error occured.</strong>
  </div>';
  }
}else{
#post new Blog
if(isset($_POST['submit'])){

  $title=secure_value($con,$_POST['title']);
  $description=secure_value($con,$_POST['short_desc']);
  $banner=$_FILES['image']['name'];
  $content=secure_value($con,$_POST['content']);
  $content=substr($content,0,  strlen($content)-237);
  $author=secure_value($con,$_POST['author']);
  $publishedOn=secure_value($con,$_POST['publishedOn']);
  $category=secure_value($con,$_POST['category']);
  $keywords=secure_value($con,$_POST['tags']);
  
  $slug=$title;
  $slug=slugify($slug);

  $slug_check=mysqli_num_rows(mysqli_query($con,"SELECT id FROM blogpost WHERE slug='$slug'"));
  if($slug_check>0){
    $row=mysqli_fetch_assoc(mysqli_query($con,"SELECT MAX(id) as id FROM blogpost"));
    $id=$row['id'];
    $slug.=$id;
  }
  if(isset($_FILES['image'])){
    $image=rand(1111111,9999999).'_'.$_FILES['image']['name'];;
    move_uploaded_file($_FILES['image']['tmp_name'],BLOG_IMAGE_SERVER_PATH.$image);
    $banner=$image;
  }

  if(mysqli_query($con,"INSERT INTO `blogpost` (`title`, `banner`, `description`, `content`, `category`, `keywords`,`date`, `author`, `slug`, `status`) VALUES ('$title', '$banner', '$description', '$content', '$category', '$keywords','$publishedOn', '$author', '$slug', '1')")){
    $error='<div class="alert alert-success" role="alert">
    <strong>Blog uploaded successfully.</strong>
  </div>';
  }else{
    $error='<div class="alert alert-danger" role="alert">
    <strong>Some error occured.</strong>
  </div>';
  }

}

if(isset($_GET['id'])){

  $id=secure_value($con,$_GET['id']);
  $res=mysqli_query($con,"SELECT * FROM blogpost WHERE id=$id");
  if($res){
    $row=mysqli_fetch_assoc($res);
    $title=$row['title'];
    $description=$row['description'];
    $banner=$row['banner'];
    $content=$row['content'];
    $author=$row['author'];
    $publishedOn=$row['date'];
    $category=$row['category'];
    $keywords=$row['keywords'];
    $required="";
  }
}

}
?>

  <link href="node_modules/froala-editor/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
  <link href="node_modules/froala-editor/css/themes/dark.css" rel="stylesheet" type="text/css" />
  <main id="main">

    <section class="hero-section inner-page">
      <div class="wave">

        <svg width="1920px" height="265px" viewBox="0 0 1920 265" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="Apple-TV" transform="translate(0.000000, -402.000000)" fill="#FFFFFF">
              <path d="M0,439.134243 C175.04074,464.89273 327.944386,477.771974 458.710937,477.771974 C654.860765,477.771974 870.645295,442.632362 1205.9828,410.192501 C1429.54114,388.565926 1667.54687,411.092417 1920,477.771974 L1920,667 L1017.15166,667 L0,667 L0,439.134243 Z" id="Path"></path>
            </g>
          </g>
        </svg>

      </div>

      <div class="container">
        <div class="row align-items-center">
          <div class="col-12">
            <div class="row justify-content-center">
              <div class="col-md-7 text-center hero-text">
                <h1 data-aos="fade-up" data-aos-delay="">All Blogs</h1>
                <p class="mb-5" data-aos="fade-up" data-aos-delay="100">Blog Master</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>

    <section class="section">
      <div class="container">
        <div class="row mb-5 align-items-end">
          <div class="col-md-6">

            <h2>Blog Master</h2>
         
          </div>

        </div>

        <div class="row">
          <div class="col-md-12 mb-5 mb-md-0" >
             <!-- content -->
             <!-- container -->
              <div class="container-fluid">
                <!-- row -->
                <div class="row p-30-0">

                  <!-- col -->
                  <div class="col-lg-12">

                    <!-- section title -->
                    <div class="art-section-title">
                      <!-- title frame -->
                      <div class="art-title-frame">
                        <!-- title -->
                        <h4>Add Blog</h4>
                      </div>
                   <?php echo $error; ?>
                      <!-- title frame end -->
                    </div>
                    <!-- section title end -->

                    <!-- contact form frame -->
                    <div class="art-a art-card">

                      <!-- contact form -->
                      <form id="addblog" method="POST" enctype="multipart/form-data" autocomplete="off" >
                        
                        <!-- form field -->
                        <div class="col-md-12 form-group mt-3">
                          <input id="title" name="title" class="form-control" type="text" placeholder="Title" required value="<?php echo $title;?>">
                          <label for="title"><i class="fas fa-heading"></i></label>
                        </div>
                        <!-- form field end -->

                        <!-- form field -->
                        <div class="col-md-12 form-group mt-3">
                            <input id="img" name="image" class="form-control" type="file" <?php echo $required; ?> value="<?php echo $banner; ?>">
                           <!-- <label for="img" class="btn" style="margin-top:-70px; background:#EE57BE;">Banner</label>-->
                            <?php if($banner!=""){
                                $thumbnail=BLOG_IMAGE_SITE_PATH.$banner;
                            echo "<img src='$thumbnail' class='img-thumbnail mt-2' style='max-height:80px; max-width:100px;'>";} ?>
                               
                        </div>
                        <!-- form field end -->

                        <!-- form field -->
                        <div class="col-md-12 form-group mt-3 short-desc">
                          <textarea id="short_desc" name="short_desc" class="form-control" placeholder="Short Description" required><?php echo htmlspecialchars($description);?></textarea>
                          <label for="short_desc"><i class="fas fa-align-left"></i></label>
                        </div>
                        <!-- form field end -->

                        <!-- form field -->
                        <div class="col-md-12 form-group mt-3">
                            <textarea class="art-input form-control" id="froala" name="content" required><?php echo ($content);?></textarea>  
                        </div>
                        <!-- form field end -->
                        
                        <!-- form field -->
                        <div class="col-md-12 form-group mt-3">
                          <input id="tags" name="tags" class="form-control" type="text" placeholder="Tags" required value="<?php echo $keywords;?>">
                          <label for="tags"><i class="fas fa-keyboard"></i></label>
                       </div>
                        <!-- form field end -->
                        
                        <div class="row align-items-center">
                            <!-- form field -->
                            <div class="col-md-4 form-group mt-3  col">
                                <input id="category" name="category" class="form-control" type="text" placeholder="Category" required value="<?php echo $category;?>">
                                <label for="category"><i class="fas fa-cubes"></i></label>
                            </div>
                            <!-- form field end -->
                            
                            <!-- form field -->
                            <div class="col-md-4 form-group mt-3  col">
                                <input id="publishedOn" name="publishedOn" class="form-control" type="text" placeholder="Publish Date" required value="<?php echo $publishedOn;?>">
                                <label for="publishedOn "><i class="fas fa-calendar-day"></i></label>
                            </div>
                            <!-- form field end -->
                        
                            <!-- form field -->
                            <div class="col-md-4 form-group mt-3 col">
                                <input id="author" name="author" class="form-control" type="text" placeholder="Author" required value="<?php echo $author;?>">
                                <label for="author"><i class="fas fa-at"></i></label>
                            </div>
                            <!-- form field end -->
                        </div>
                        <!-- form field end -->
      
                        <!-- button -->
                        <div class="art-submit-frame">
                            <button type="submit" name="submit" class="btn btn-primary">Post</button>
                        </div>
                      </form>
                      <!-- contact form end -->

                    </div>
                    <!-- contact form frame end -->

                  </div>
                  <!-- col end -->

                </div>
                <!-- row end -->

              </div>
              <!-- container end -->
             <!-- content end -->
          </div>

        </div>
      </div>
    </section>

   
  </main><!-- End #main -->
  
  <script type="text/javascript" src="node_modules/froala-editor/js/froala_editor.pkgd.min.js"></script>

  <script> 
      new FroalaEditor('#froala', {
        // Set the image upload URL.
        imageUploadURL: 'uploads',
        imageUploadParam: 'image_param',
        events: {
        'image.removed': function ($img) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {

          // Image was removed.
          if (this.readyState == 4 && this.status == 200) {
             console.log ('image was deleted');
          }
        };
        xhttp.open("POST", "https://friendforyou.000webhostapp.com/admin/delete_uploads", true);
         xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.send(JSON.stringify({
          src: $img.attr('src')
        }));
      }
    },
    codeBeautifierOptions: {
    end_with_newline: true,
    indent_inner_html: true,
    extra_liners: "['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'pre', 'ul', 'ol', 'table', 'dl']",
    brace_style: 'expand',
    indent_char: ' ',
    indent_size: 4,
    wrap_line_length: 0
    },
     pastePlain: true
      });
      
  var today = new Date();
  var dd = today.getDate();

  var mm = today.getMonth()+1; 
  var yyyy = today.getFullYear();
  if(dd<10) 
  {
      dd='0'+dd;
  } 

  if(mm<10) 
  {
      mm='0'+mm;
  } 
  today = dd+'.'+mm+'.'+yyyy;
  if (document.getElementById('publishedOn').value=="")
  document.getElementById('publishedOn').value=today
  </script>
<?php include('footer.php'); ?>