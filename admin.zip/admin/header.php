<?php include('connection.inc.php'); 
if (!isset($_SESSION['user_id'])) {
    header('Location: /admin');
    exit;
}else{
    $adminName=$_SESSION['adminName'];
}

// Registering new Admin
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['registerAdmin'])) {
    // Get form data
    $fullName = secure_value($con, $_POST["fullName"]);
    $username = secure_value($con, $_POST["username"]);
    $email = secure_value($con, $_POST["email"]);
    $password = secure_value($con, $_POST["password"]);
    $addedOn = date("Y-m-d H:i:s");

    // Check if the username or email already exist in the database
    $checkQuery = "SELECT * FROM admins WHERE username='$username' OR email='$email'";
    $result = mysqli_query($con, $checkQuery);
    $existingAdmin = mysqli_fetch_assoc($result);

    if ($existingAdmin) {
        // The username or email already exists, show error message
        echo "<script> alert('Error: Username or email already exists!') </script>";
    } else {
        // Insert the new admin into the database
        // Hash the new password before updating in the database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $insertQuery = "INSERT INTO admins (fullName, username, email, password, addedOn) VALUES ('$fullName', '$username', '$email', '$hashedPassword', '$addedOn')";

        if (mysqli_query($con, $insertQuery)) {
            echo "<script> alert('Registration successful!') </script>";
        } else {
            echo "<script> alert('Error: " . $insertQuery . "<br>" . mysqli_error($con)."') </script>";
        }
    }

    mysqli_close($con);
}


// Password Change 
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['changePassword'])) {
    // Get form data
    $oldPassword = $_POST["oldPassword"];
    $newPassword = $_POST["newPassword"];
    $confirmPassword = $_POST["confirmPassword"];

    // Validate the old password
    $userId = $_SESSION['user_id'];
    $getUserQuery = "SELECT password FROM admins WHERE id = $userId";
    $result = mysqli_query($con, $getUserQuery);
    $userData = mysqli_fetch_assoc($result);

    if (!$userData || !password_verify($oldPassword, $userData['password'])) {
        echo "<script> alert('Error: Incorrect old password!') </script>";
    } else {
        // If new and confirm passwords match
        if ($newPassword === $confirmPassword) {
            // Hash the new password before updating in the database
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            $sql = "UPDATE admins SET password = '$hashedPassword' WHERE id = $userId";

            if (mysqli_query($con, $sql)) {
                echo "<script> alert('Password changed successfully!') </script>";
            } else {
                echo "<script> alert('Error updating record: " . mysqli_error($con)."') </script>";
            }

            mysqli_close($con);
        } else {
            echo "<script> alert('New password and confirm password do not match!') </script>";
        }
    }
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <?php
    // Get the page title based on the current page URL
    $pageTitle = '';
    $baseURL = 'https://' . $_SERVER['HTTP_HOST'];
    $currentPage = $_SERVER['REQUEST_URI'];
    $currentURL = $baseURL . $currentPage;
    // Explode the current page URL by '/' delimiter
    $urlComponents = explode('/', $currentPage);

    // Get the last component of the URL (page name)
    $pageName = end($urlComponents);
    $indexActive = "";
    $blogMasterActive="";
    $description = "";

    // Map page name to the corresponding title
    switch ($pageName) {
        case '':
             $pageTitle = '-Admin Panel';
            $indexActive = "active";
            $contactActive = "";
            $otherActive = "";
            $description = "";
            break;
        case 'index':
            $pageTitle = '-Admin Panel';
            $indexActive = "active";
            $contactActive = "";
            $otherActive = "";
            $description = "";
            break;
        case 'blog-master':
        $pageTitle = '-Blog Master';
        $blogMasterActive = "active";
        $contactActive = "";
        $otherActive = "";
        $description = "";
            break;
     
        default:
            $pageTitle = '';
            $indexActive = "";
            $contactActive = "";
            $otherActive = "";
            $description = "Oops! The page you're looking for does not exist. Explore the Connect-App to find genuine connections, empathetic relationships, and support for mentally ill and shy individuals. Visit our homepage or contact us to learn more about our dating app.";
            break;
    }

    echo '<title>Connect ' . $pageTitle . '</title>';
    ?>
    <meta content="<?php echo $description; ?>" name="description">
    <meta content="Dating app, mentally ill, shy individuals, mindful matching, safety, community-driven support, genuine connections, empathy, relationships" name="keywords">
    <meta name="robots" content="index, follow">

    <meta name="theme-color" content="#e84a5f">

    <meta property="og:title" content="Connect-App::<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $description; ?>">
    <meta property="og:image" content="/assets/img/favicon.ico">
    <meta property="og:url" content="<?php echo $currentURL; ?>">
    <meta property="og:type" content="website">


    <!-- Favicons -->
    <link href="/assets/img/favicon.ico" rel="icon">
    <link href="/assets/img/favicon.ico" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,600,600i,700,700i Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="/assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: Connect-App
  * Updated: July 20 2023 with Bootstrap v5.3.0
  * Developer: Offensive Technology
  ======================================================== -->
</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top d-flex align-items-center">
        <div class="container d-flex justify-content-between align-items-center">

            <div class="logo py-3">
                <a href="admin"><img src="/assets/img/logo.png" alt="conect logo" class = "img-fluid"></a>
            </div>

            <nav id="navbar" class="navbar">
                <ul>
                    <li><a class="<?php echo $indexActive; ?>" href="/admin/dashboard">Home</a></li>
                    <li><a class="<?php echo $blogMasterActive; ?>" href="blog-master">Blog Master</a></li>
                    <li class="dropdown"><a class="<?php echo $otherActive; ?>"><span><?php echo $adminName;?></span> <i class="bi bi-chevron-down"></i></a>
                        <ul>
                            <li><a data-toggle="modal" data-target="#forgotPasswordModal">Change Password</a></li>
                            <li><a data-toggle="modal" data-target="#registerModal">Register Admin</a></li>
                            <li><a href="logout">Logout</a></li>
                        </ul>
                    </li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>

            </nav><!-- navbar -->
        </div>
    </header><!-- End Header -->
     <!-- Registration Modal -->
    <div class="modal fade" id="registerModal" tabindex="-1" role="dialog" aria-labelledby="registerModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="registerModalLabel">Register</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Registration Form -->
                    <form id="registrationForm" method="POST" action="">
                        <div class="form-group">
                            <label for="fullName">Full Name:</label>
                            <input type="text" class="form-control" id="fullName" name="fullName" required>
                        </div>
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" name="registerAdmin" class="btn btn-primary">Register</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div class="modal fade" id="forgotPasswordModal" tabindex="-1" role="dialog" aria-labelledby="forgotPasswordModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="forgotPasswordModalLabel">Forgot Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Forgot Password Form -->
                    <form id="forgotPasswordForm" method="POST" action="">
                        <div class="form-group">
                            <label for="oldPassword">Old Password:</label>
                            <input type="password" class="form-control" id="oldPassword" name="oldPassword" required>
                        </div>
                        <div class="form-group">
                            <label for="newPassword">New Password:</label>
                            <input type="password" class="form-control" id="newPassword" name="newPassword" required>
                        </div>
                        <div class="form-group">
                            <label for="confirmPassword">Confirm Password:</label>
                            <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                        </div>
                        <button type="submit" name="changePassword" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

